// Generated from openapi/control-plane.openapi.json. Do not edit.
export interface paths {
    "/presentations": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Collection */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            presentations: {
                                id: string;
                                revision: number;
                                name: string;
                                /** @description Atomic presentation definition. IDs are unique within their documented scope; all asset, zone, element, step, and group references must resolve. Step transitions cannot cross group boundaries. */
                                definition: {
                                    /** @enum {number} */
                                    schemaVersion: 1;
                                    metadata: {
                                        title: string;
                                        description?: string;
                                    };
                                    stage: {
                                        coordinateSystem: {
                                            /** @enum {string} */
                                            unit: "meter";
                                            /** @enum {string} */
                                            handedness: "right";
                                            /** @enum {string} */
                                            upAxis: "+Y";
                                            /** @enum {string} */
                                            forwardAxis: "-Z";
                                        };
                                        size: number[];
                                        zones: {
                                            id: string;
                                            bounds: {
                                                min: number[];
                                                max: number[];
                                            };
                                        }[];
                                    };
                                    assets: {
                                        assetId: string;
                                    }[];
                                    groups: {
                                        id: string;
                                        elements: ({
                                            id: string;
                                            /** @enum {string} */
                                            type: "text";
                                            content: {
                                                text: string;
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        } | {
                                            id: string;
                                            /** @enum {string} */
                                            type: "shape";
                                            content: {
                                                /** @enum {string} */
                                                shape: "cube" | "sphere" | "plane";
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        } | {
                                            id: string;
                                            /** @enum {string} */
                                            type: "image";
                                            content: {
                                                assetId: string;
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        } | {
                                            id: string;
                                            /** @enum {string} */
                                            type: "video";
                                            content: {
                                                assetId: string;
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        } | {
                                            id: string;
                                            /** @enum {string} */
                                            type: "model";
                                            content: {
                                                assetId: string;
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        } | {
                                            id: string;
                                            /** @enum {string} */
                                            type: "audio";
                                            content: {
                                                assetId: string;
                                            };
                                            initialState: {
                                                active: boolean;
                                                visible: boolean;
                                                opacity: number;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                            };
                                        })[];
                                        anchoredElementGroups: {
                                            id: string;
                                            /** @enum {string} */
                                            anchor: "head" | "leftHand" | "rightHand" | "body";
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                            elementIds: string[];
                                        }[];
                                        steps: {
                                            id: string;
                                            cues: {
                                                id: string;
                                                trigger: {
                                                    /** @enum {string} */
                                                    kind: "button";
                                                    action: string;
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "enterZone";
                                                    zoneId: string;
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "motion";
                                                    minimumDistanceMeters: number;
                                                };
                                                actions: ({
                                                    /** @enum {string} */
                                                    kind: "setActive";
                                                    targetElementId: string;
                                                    active: boolean;
                                                    transition?: {
                                                        durationSeconds: number;
                                                        delaySeconds: number;
                                                    };
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "setVisible";
                                                    targetElementId: string;
                                                    visible: boolean;
                                                    transition?: {
                                                        durationSeconds: number;
                                                        delaySeconds: number;
                                                    };
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "setOpacity";
                                                    targetElementId: string;
                                                    opacity: number;
                                                    transition?: {
                                                        durationSeconds: number;
                                                        delaySeconds: number;
                                                    };
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "setTransform";
                                                    targetElementId: string;
                                                    transform: {
                                                        position: number[];
                                                        /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                        rotation: number[];
                                                        scale: number[];
                                                    };
                                                    transition?: {
                                                        durationSeconds: number;
                                                        delaySeconds: number;
                                                    };
                                                })[];
                                                next: {
                                                    /** @enum {string} */
                                                    kind: "step";
                                                    stepId: string;
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "group";
                                                    groupId: string;
                                                } | {
                                                    /** @enum {string} */
                                                    kind: "end";
                                                };
                                            }[];
                                        }[];
                                    }[];
                                } | null;
                                createdAt: string;
                                updatedAt: string;
                            }[];
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        id: string;
                        name: string;
                    };
                };
            };
            responses: {
                /** @description Created */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            id: string;
                            revision: number;
                            name: string;
                            /** @description Atomic presentation definition. IDs are unique within their documented scope; all asset, zone, element, step, and group references must resolve. Step transitions cannot cross group boundaries. */
                            definition: {
                                /** @enum {number} */
                                schemaVersion: 1;
                                metadata: {
                                    title: string;
                                    description?: string;
                                };
                                stage: {
                                    coordinateSystem: {
                                        /** @enum {string} */
                                        unit: "meter";
                                        /** @enum {string} */
                                        handedness: "right";
                                        /** @enum {string} */
                                        upAxis: "+Y";
                                        /** @enum {string} */
                                        forwardAxis: "-Z";
                                    };
                                    size: number[];
                                    zones: {
                                        id: string;
                                        bounds: {
                                            min: number[];
                                            max: number[];
                                        };
                                    }[];
                                };
                                assets: {
                                    assetId: string;
                                }[];
                                groups: {
                                    id: string;
                                    elements: ({
                                        id: string;
                                        /** @enum {string} */
                                        type: "text";
                                        content: {
                                            text: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "shape";
                                        content: {
                                            /** @enum {string} */
                                            shape: "cube" | "sphere" | "plane";
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "image";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "video";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "model";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "audio";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    })[];
                                    anchoredElementGroups: {
                                        id: string;
                                        /** @enum {string} */
                                        anchor: "head" | "leftHand" | "rightHand" | "body";
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                        elementIds: string[];
                                    }[];
                                    steps: {
                                        id: string;
                                        cues: {
                                            id: string;
                                            trigger: {
                                                /** @enum {string} */
                                                kind: "button";
                                                action: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "enterZone";
                                                zoneId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "motion";
                                                minimumDistanceMeters: number;
                                            };
                                            actions: ({
                                                /** @enum {string} */
                                                kind: "setActive";
                                                targetElementId: string;
                                                active: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setVisible";
                                                targetElementId: string;
                                                visible: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setOpacity";
                                                targetElementId: string;
                                                opacity: number;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setTransform";
                                                targetElementId: string;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            })[];
                                            next: {
                                                /** @enum {string} */
                                                kind: "step";
                                                stepId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "group";
                                                groupId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "end";
                                            };
                                        }[];
                                    }[];
                                }[];
                            } | null;
                            createdAt: string;
                            updatedAt: string;
                        };
                    };
                };
                /** @description Invalid presentation registration */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Presentation ID is not writable */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{id}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Presentation */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            id: string;
                            revision: number;
                            name: string;
                            /** @description Atomic presentation definition. IDs are unique within their documented scope; all asset, zone, element, step, and group references must resolve. Step transitions cannot cross group boundaries. */
                            definition: {
                                /** @enum {number} */
                                schemaVersion: 1;
                                metadata: {
                                    title: string;
                                    description?: string;
                                };
                                stage: {
                                    coordinateSystem: {
                                        /** @enum {string} */
                                        unit: "meter";
                                        /** @enum {string} */
                                        handedness: "right";
                                        /** @enum {string} */
                                        upAxis: "+Y";
                                        /** @enum {string} */
                                        forwardAxis: "-Z";
                                    };
                                    size: number[];
                                    zones: {
                                        id: string;
                                        bounds: {
                                            min: number[];
                                            max: number[];
                                        };
                                    }[];
                                };
                                assets: {
                                    assetId: string;
                                }[];
                                groups: {
                                    id: string;
                                    elements: ({
                                        id: string;
                                        /** @enum {string} */
                                        type: "text";
                                        content: {
                                            text: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "shape";
                                        content: {
                                            /** @enum {string} */
                                            shape: "cube" | "sphere" | "plane";
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "image";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "video";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "model";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "audio";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    })[];
                                    anchoredElementGroups: {
                                        id: string;
                                        /** @enum {string} */
                                        anchor: "head" | "leftHand" | "rightHand" | "body";
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                        elementIds: string[];
                                    }[];
                                    steps: {
                                        id: string;
                                        cues: {
                                            id: string;
                                            trigger: {
                                                /** @enum {string} */
                                                kind: "button";
                                                action: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "enterZone";
                                                zoneId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "motion";
                                                minimumDistanceMeters: number;
                                            };
                                            actions: ({
                                                /** @enum {string} */
                                                kind: "setActive";
                                                targetElementId: string;
                                                active: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setVisible";
                                                targetElementId: string;
                                                visible: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setOpacity";
                                                targetElementId: string;
                                                opacity: number;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setTransform";
                                                targetElementId: string;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            })[];
                                            next: {
                                                /** @enum {string} */
                                                kind: "step";
                                                stepId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "group";
                                                groupId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "end";
                                            };
                                        }[];
                                    }[];
                                }[];
                            } | null;
                            createdAt: string;
                            updatedAt: string;
                        };
                    };
                };
                /** @description Invalid presentation id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        expectedRevision: number;
                        /** @description Atomic presentation definition. IDs are unique within their documented scope; all asset, zone, element, step, and group references must resolve. Step transitions cannot cross group boundaries. */
                        definition: {
                            /** @enum {number} */
                            schemaVersion: 1;
                            metadata: {
                                title: string;
                                description?: string;
                            };
                            stage: {
                                coordinateSystem: {
                                    /** @enum {string} */
                                    unit: "meter";
                                    /** @enum {string} */
                                    handedness: "right";
                                    /** @enum {string} */
                                    upAxis: "+Y";
                                    /** @enum {string} */
                                    forwardAxis: "-Z";
                                };
                                size: number[];
                                zones: {
                                    id: string;
                                    bounds: {
                                        min: number[];
                                        max: number[];
                                    };
                                }[];
                            };
                            assets: {
                                assetId: string;
                            }[];
                            groups: {
                                id: string;
                                elements: ({
                                    id: string;
                                    /** @enum {string} */
                                    type: "text";
                                    content: {
                                        text: string;
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                } | {
                                    id: string;
                                    /** @enum {string} */
                                    type: "shape";
                                    content: {
                                        /** @enum {string} */
                                        shape: "cube" | "sphere" | "plane";
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                } | {
                                    id: string;
                                    /** @enum {string} */
                                    type: "image";
                                    content: {
                                        assetId: string;
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                } | {
                                    id: string;
                                    /** @enum {string} */
                                    type: "video";
                                    content: {
                                        assetId: string;
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                } | {
                                    id: string;
                                    /** @enum {string} */
                                    type: "model";
                                    content: {
                                        assetId: string;
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                } | {
                                    id: string;
                                    /** @enum {string} */
                                    type: "audio";
                                    content: {
                                        assetId: string;
                                    };
                                    initialState: {
                                        active: boolean;
                                        visible: boolean;
                                        opacity: number;
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                    };
                                })[];
                                anchoredElementGroups: {
                                    id: string;
                                    /** @enum {string} */
                                    anchor: "head" | "leftHand" | "rightHand" | "body";
                                    transform: {
                                        position: number[];
                                        /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                        rotation: number[];
                                        scale: number[];
                                    };
                                    elementIds: string[];
                                }[];
                                steps: {
                                    id: string;
                                    cues: {
                                        id: string;
                                        trigger: {
                                            /** @enum {string} */
                                            kind: "button";
                                            action: string;
                                        } | {
                                            /** @enum {string} */
                                            kind: "enterZone";
                                            zoneId: string;
                                        } | {
                                            /** @enum {string} */
                                            kind: "motion";
                                            minimumDistanceMeters: number;
                                        };
                                        actions: ({
                                            /** @enum {string} */
                                            kind: "setActive";
                                            targetElementId: string;
                                            active: boolean;
                                            transition?: {
                                                durationSeconds: number;
                                                delaySeconds: number;
                                            };
                                        } | {
                                            /** @enum {string} */
                                            kind: "setVisible";
                                            targetElementId: string;
                                            visible: boolean;
                                            transition?: {
                                                durationSeconds: number;
                                                delaySeconds: number;
                                            };
                                        } | {
                                            /** @enum {string} */
                                            kind: "setOpacity";
                                            targetElementId: string;
                                            opacity: number;
                                            transition?: {
                                                durationSeconds: number;
                                                delaySeconds: number;
                                            };
                                        } | {
                                            /** @enum {string} */
                                            kind: "setTransform";
                                            targetElementId: string;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                            transition?: {
                                                durationSeconds: number;
                                                delaySeconds: number;
                                            };
                                        })[];
                                        next: {
                                            /** @enum {string} */
                                            kind: "step";
                                            stepId: string;
                                        } | {
                                            /** @enum {string} */
                                            kind: "group";
                                            groupId: string;
                                        } | {
                                            /** @enum {string} */
                                            kind: "end";
                                        };
                                    }[];
                                }[];
                            }[];
                        };
                    };
                };
            };
            responses: {
                /** @description Updated */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            id: string;
                            revision: number;
                            name: string;
                            /** @description Atomic presentation definition. IDs are unique within their documented scope; all asset, zone, element, step, and group references must resolve. Step transitions cannot cross group boundaries. */
                            definition: {
                                /** @enum {number} */
                                schemaVersion: 1;
                                metadata: {
                                    title: string;
                                    description?: string;
                                };
                                stage: {
                                    coordinateSystem: {
                                        /** @enum {string} */
                                        unit: "meter";
                                        /** @enum {string} */
                                        handedness: "right";
                                        /** @enum {string} */
                                        upAxis: "+Y";
                                        /** @enum {string} */
                                        forwardAxis: "-Z";
                                    };
                                    size: number[];
                                    zones: {
                                        id: string;
                                        bounds: {
                                            min: number[];
                                            max: number[];
                                        };
                                    }[];
                                };
                                assets: {
                                    assetId: string;
                                }[];
                                groups: {
                                    id: string;
                                    elements: ({
                                        id: string;
                                        /** @enum {string} */
                                        type: "text";
                                        content: {
                                            text: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "shape";
                                        content: {
                                            /** @enum {string} */
                                            shape: "cube" | "sphere" | "plane";
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "image";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "video";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "model";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    } | {
                                        id: string;
                                        /** @enum {string} */
                                        type: "audio";
                                        content: {
                                            assetId: string;
                                        };
                                        initialState: {
                                            active: boolean;
                                            visible: boolean;
                                            opacity: number;
                                            transform: {
                                                position: number[];
                                                /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                rotation: number[];
                                                scale: number[];
                                            };
                                        };
                                    })[];
                                    anchoredElementGroups: {
                                        id: string;
                                        /** @enum {string} */
                                        anchor: "head" | "leftHand" | "rightHand" | "body";
                                        transform: {
                                            position: number[];
                                            /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                            rotation: number[];
                                            scale: number[];
                                        };
                                        elementIds: string[];
                                    }[];
                                    steps: {
                                        id: string;
                                        cues: {
                                            id: string;
                                            trigger: {
                                                /** @enum {string} */
                                                kind: "button";
                                                action: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "enterZone";
                                                zoneId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "motion";
                                                minimumDistanceMeters: number;
                                            };
                                            actions: ({
                                                /** @enum {string} */
                                                kind: "setActive";
                                                targetElementId: string;
                                                active: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setVisible";
                                                targetElementId: string;
                                                visible: boolean;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setOpacity";
                                                targetElementId: string;
                                                opacity: number;
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            } | {
                                                /** @enum {string} */
                                                kind: "setTransform";
                                                targetElementId: string;
                                                transform: {
                                                    position: number[];
                                                    /** @description Normalized [x, y, z, w] quaternion; the server accepts a norm tolerance of 0.0001. */
                                                    rotation: number[];
                                                    scale: number[];
                                                };
                                                transition?: {
                                                    durationSeconds: number;
                                                    delaySeconds: number;
                                                };
                                            })[];
                                            next: {
                                                /** @enum {string} */
                                                kind: "step";
                                                stepId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "group";
                                                groupId: string;
                                            } | {
                                                /** @enum {string} */
                                                kind: "end";
                                            };
                                        }[];
                                    }[];
                                }[];
                            } | null;
                            createdAt: string;
                            updatedAt: string;
                        };
                    };
                };
                /** @description Invalid presentation update */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Revision conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Asset reference is not ready or does not belong to this presentation */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        post?: never;
        delete: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        expectedRevision: number;
                    };
                };
            };
            responses: {
                /** @description Deleted */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid delete request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Revision conflict or presentation assets must be deleted first */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/assets/uploads": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        presentationId: string;
                        name: string;
                        /** @enum {string} */
                        mediaType: "image/png" | "image/jpeg" | "image/webp" | "video/mp4" | "audio/mpeg" | "model/gltf-binary";
                        sizeBytes: number;
                        sha256Hex: string;
                    };
                };
            };
            responses: {
                /** @description Upload initialized */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            asset: {
                                id: string;
                                presentationId: string;
                                name: string;
                                /** @enum {string} */
                                mediaType: "image/png" | "image/jpeg" | "image/webp" | "video/mp4" | "audio/mpeg" | "model/gltf-binary";
                                sizeBytes: number;
                                sha256Hex: string;
                                /** @enum {string} */
                                status: "pending" | "ready" | "failed" | "deleting";
                                createdAt: string;
                                updatedAt: string;
                            };
                            upload: {
                                /** @enum {string} */
                                method: "PUT";
                                /** Format: uri */
                                url: string;
                                expiresAt: string;
                                headers: {
                                    /** @enum {string} */
                                    "content-type": "image/png" | "image/jpeg" | "image/webp" | "video/mp4" | "audio/mpeg" | "model/gltf-binary";
                                    "content-length": string;
                                    "x-amz-checksum-sha256": string;
                                };
                            };
                        };
                    };
                };
                /** @description Invalid upload */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Signing unavailable */
                503: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/assets/{id}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Asset */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            id: string;
                            presentationId: string;
                            name: string;
                            /** @enum {string} */
                            mediaType: "image/png" | "image/jpeg" | "image/webp" | "video/mp4" | "audio/mpeg" | "model/gltf-binary";
                            sizeBytes: number;
                            sha256Hex: string;
                            /** @enum {string} */
                            status: "pending" | "ready" | "failed" | "deleting";
                            createdAt: string;
                            updatedAt: string;
                        };
                    };
                };
                /** @description Invalid asset id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Deleted */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid asset id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Referenced */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/assets/{id}/finalize": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Finalized */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            id: string;
                            presentationId: string;
                            name: string;
                            /** @enum {string} */
                            mediaType: "image/png" | "image/jpeg" | "image/webp" | "video/mp4" | "audio/mpeg" | "model/gltf-binary";
                            sizeBytes: number;
                            sha256Hex: string;
                            /** @enum {string} */
                            status: "pending" | "ready" | "failed" | "deleting";
                            createdAt: string;
                            updatedAt: string;
                        };
                    };
                };
                /** @description Invalid asset id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Verification failed */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/assets/{id}/download": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Download access */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            download: {
                                /** @enum {string} */
                                method: "GET";
                                /** Format: uri */
                                url: string;
                                expiresAt: string;
                            };
                        };
                    };
                };
                /** @description Invalid asset id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Access unavailable */
                503: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: {
                    limit?: number;
                    cursor?: string;
                };
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Rooms created by the authenticated account, newest first; cursor is the last returned id */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            sessions: {
                                publicationFence: {
                                    presentationId: string;
                                    publicationEpoch: number;
                                    publicationManifestHash: string;
                                } | null;
                                id: string;
                                presentationId: string;
                                presenterId: string;
                                /** @enum {string} */
                                state: "Waiting" | "Presenting" | "Ended";
                                participantCount: number;
                                /** @enum {number} */
                                maxParticipants: 50;
                                /** Format: date-time */
                                createdAt: string;
                                /** Format: date-time */
                                endedAt: string | null;
                            }[];
                            nextCursor: string | null;
                        };
                    };
                };
                /** @description Invalid pagination */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Cursor not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        presentationId: string;
                    };
                };
            };
            responses: {
                /** @description Created */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            session: {
                                publicationFence: {
                                    presentationId: string;
                                    publicationEpoch: number;
                                    publicationManifestHash: string;
                                } | null;
                                id: string;
                                presentationId: string;
                                presenterId: string;
                                /** @enum {string} */
                                state: "Waiting" | "Presenting" | "Ended";
                                participantCount: number;
                                /** @enum {number} */
                                maxParticipants: 50;
                                /** Format: date-time */
                                createdAt: string;
                                /** Format: date-time */
                                endedAt: string | null;
                            };
                            joinCode: string;
                        };
                    };
                };
                /** @description Invalid session */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Presentation not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description No published presentation */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}/join-code": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Current join code, available only to the creator; Cache-Control: no-store */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            joinCode: string;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Creator required */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Code unavailable */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Replaced join code; previous code cannot be used to join; Cache-Control: no-store */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            joinCode: string;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Creator required */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Ended, concurrent rotation, or code collision */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/join": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        joinCode: string;
                    };
                };
            };
            responses: {
                /** @description Joined */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            publicationFence: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                            } | null;
                            id: string;
                            presentationId: string;
                            presenterId: string;
                            /** @enum {string} */
                            state: "Waiting" | "Presenting" | "Ended";
                            participantCount: number;
                            /** @enum {number} */
                            maxParticipants: 50;
                            /** Format: date-time */
                            createdAt: string;
                            /** Format: date-time */
                            endedAt: string | null;
                        };
                    };
                };
                /** @description Invalid join code */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Viewer credential is scoped to another session */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session full */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
                /** @description Rate limited */
                429: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Session */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            publicationFence: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                            } | null;
                            id: string;
                            presentationId: string;
                            presenterId: string;
                            /** @enum {string} */
                            state: "Waiting" | "Presenting" | "Ended";
                            participantCount: number;
                            /** @enum {number} */
                            maxParticipants: 50;
                            /** Format: date-time */
                            createdAt: string;
                            /** Format: date-time */
                            endedAt: string | null;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}/start": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Presenting */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            publicationFence: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                            } | null;
                            id: string;
                            presentationId: string;
                            presenterId: string;
                            /** @enum {string} */
                            state: "Waiting" | "Presenting" | "Ended";
                            participantCount: number;
                            /** @enum {number} */
                            maxParticipants: 50;
                            /** Format: date-time */
                            createdAt: string;
                            /** Format: date-time */
                            endedAt: string | null;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid transition */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}/end": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Ended */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            publicationFence: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                            } | null;
                            id: string;
                            presentationId: string;
                            presenterId: string;
                            /** @enum {string} */
                            state: "Waiting" | "Presenting" | "Ended";
                            participantCount: number;
                            /** @enum {number} */
                            maxParticipants: 50;
                            /** Format: date-time */
                            createdAt: string;
                            /** Format: date-time */
                            endedAt: string | null;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid transition */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}/bootstrap": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Realtime connection */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** Format: uri */
                            endpoint: string;
                            fingerprint: string | null;
                            runtimeId: string;
                            /** @enum {string} */
                            runtimeKind: "Cloud" | "VenueEdge";
                            assignmentEpoch: number;
                            presentationId: string;
                            presentationRevision: number;
                            credential: string;
                            /** Format: date-time */
                            expiresAt: string;
                            publicationFence: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                            };
                            projectionProfileId: string;
                        };
                    };
                };
                /** @description Invalid id */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session conflict; runtime_unavailable is retryable while Runtime is unavailable */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/viewer-credentials": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        /** @description Join as an anonymous viewer. Bearer credentials expire after one hour and may be rotated for up to 24 hours. */
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        joinCode: string;
                    };
                };
            };
            responses: {
                /** @description Viewer credential */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            token: string;
                            /** Format: date-time */
                            expiresAt: string;
                            sessionId: string;
                            participantId: string;
                        };
                    };
                };
                /** @description Invalid request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid join code */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session full */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Join rate limited */
                429: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Revoked */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid credential */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/viewer-credentials/refresh": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        /** @description Rotate a valid viewer credential. The previous token is immediately invalidated. */
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Rotated credential */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            token: string;
                            /** Format: date-time */
                            expiresAt: string;
                            sessionId: string;
                            participantId: string;
                        };
                    };
                };
                /** @description Expired or revoked credential */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{sessionId}/runtime-assignment": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    sessionId: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Active assignment */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            sessionId: string;
                            runtimeId: string;
                            /** @enum {string} */
                            runtimeKind: "Cloud" | "VenueEdge";
                            /** Format: uri */
                            endpoint: string;
                            certificateFingerprint: string | null;
                            provisioningEdgeId: string | null;
                            assignmentEpoch: number;
                            presentationRevision: number;
                            /** Format: date-time */
                            issuedAt: string;
                            /** Format: date-time */
                            leaseExpiresAt: string;
                            /** Format: date-time */
                            releasedAt: string | null;
                        };
                    };
                };
                /** @description Invalid session ID */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description No active assignment */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    sessionId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        runtimeId: string;
                        /** @enum {string} */
                        runtimeKind: "Cloud" | "VenueEdge";
                        /** Format: uri */
                        endpoint?: string;
                        presentationRevision: number;
                        /** Format: date-time */
                        leaseExpiresAt: string;
                    };
                };
            };
            responses: {
                /** @description Assigned */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            sessionId: string;
                            runtimeId: string;
                            /** @enum {string} */
                            runtimeKind: "Cloud" | "VenueEdge";
                            /** Format: uri */
                            endpoint: string;
                            certificateFingerprint: string | null;
                            provisioningEdgeId: string | null;
                            assignmentEpoch: number;
                            presentationRevision: number;
                            /** Format: date-time */
                            issuedAt: string;
                            /** Format: date-time */
                            leaseExpiresAt: string;
                            /** Format: date-time */
                            releasedAt: string | null;
                        };
                    };
                };
                /** @description Invalid assignment request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Active assignment exists */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/hosts/{runtimeId}/start": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    runtimeId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: uri */
                        endpoint: string;
                        bootId: string;
                        capacity: number;
                        accepting: boolean;
                        /** Format: date-time */
                        bootStartedAt: string;
                    };
                };
            };
            responses: {
                /** @description Registered Host execution generation */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            generation: number;
                        };
                    };
                };
                /** @description Invalid host registration */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized service */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Stale boot or endpoint conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/hosts/{runtimeId}/heartbeat": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    runtimeId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: uri */
                        endpoint: string;
                        bootId: string;
                        capacity: number;
                        accepting: boolean;
                        generation: number;
                        sessions: {
                            sessionId: string;
                            assignmentEpoch: number;
                            /** @enum {string} */
                            state: "starting" | "recovering" | "ready" | "stopping" | "stopped" | "failed";
                        }[];
                    };
                };
            };
            responses: {
                /** @description Assignments owned by this Host execution generation */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            generation: number;
                            assignments: {
                                sessionId: string;
                                runtimeId: string;
                                /** @enum {string} */
                                runtimeKind: "Cloud" | "VenueEdge";
                                /** Format: uri */
                                endpoint: string;
                                certificateFingerprint: string | null;
                                provisioningEdgeId: string | null;
                                assignmentEpoch: number;
                                presentationRevision: number;
                                /** Format: date-time */
                                issuedAt: string;
                                /** Format: date-time */
                                leaseExpiresAt: string;
                                /** Format: date-time */
                                releasedAt: string | null;
                                recovery: boolean;
                            }[];
                        };
                    };
                };
                /** @description Invalid host heartbeat */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized service */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Stale Host generation or endpoint conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{id}/runtime-preparation": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Runtime preparation status */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** @enum {string} */
                            state: "unassigned";
                        } | {
                            /** @enum {string} */
                            state: "ended";
                        } | {
                            /** @enum {string} */
                            state: "starting" | "ready";
                            runtimeId: string;
                            assignmentEpoch: number;
                            /** Format: date-time */
                            leaseExpiresAt: string;
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    id: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Runtime preparation status */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** @enum {string} */
                            state: "unassigned";
                        } | {
                            /** @enum {string} */
                            state: "ended";
                        } | {
                            /** @enum {string} */
                            state: "starting" | "ready";
                            runtimeId: string;
                            assignmentEpoch: number;
                            /** Format: date-time */
                            leaseExpiresAt: string;
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime unavailable, unpublished or ended Session */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: date-time */
                        expiresAt: string;
                    };
                };
            };
            responses: {
                /** @description Provisioned */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            edge: {
                                id: string;
                                /** @enum {string} */
                                status: "active" | "revoked";
                            };
                            token: string;
                        };
                    };
                };
                /** @description Invalid provisioning request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid credential expiry */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges/{edgeId}/rotate": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    edgeId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: date-time */
                        expiresAt: string;
                        /** Format: date-time */
                        overlapExpiresAt: string;
                    };
                };
            };
            responses: {
                /** @description Rotated */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            tokenId: string;
                            token: string;
                        };
                    };
                };
                /** @description Invalid rotation request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid credential expiry */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges/{edgeId}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post?: never;
        delete: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    edgeId: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Revoked */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid Edge ID */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges/{edgeId}/register": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    edgeId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        runtimeId: string;
                        runtimeVersion: string;
                        /** @enum {string} */
                        protocolVersion: "v3";
                        capacity: number;
                        /** Format: uri */
                        localEndpoint: string;
                        certificateFingerprint: string;
                        health: string;
                    };
                };
            };
            responses: {
                /** @description Registered */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid registration */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime identity conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges/{edgeId}/assignments/{sessionId}/{assignmentEpoch}/renew": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    edgeId: string;
                    sessionId: string;
                    assignmentEpoch: number;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: date-time */
                        leaseExpiresAt: string;
                    };
                };
            };
            responses: {
                /** @description Renewed */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            sessionId: string;
                            runtimeId: string;
                            /** @enum {string} */
                            runtimeKind: "Cloud" | "VenueEdge";
                            /** Format: uri */
                            endpoint: string;
                            certificateFingerprint: string | null;
                            provisioningEdgeId: string | null;
                            assignmentEpoch: number;
                            presentationRevision: number;
                            /** Format: date-time */
                            issuedAt: string;
                            /** Format: date-time */
                            leaseExpiresAt: string;
                            /** Format: date-time */
                            releasedAt: string | null;
                        };
                    };
                };
                /** @description Invalid lease renewal */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid lease */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/venue-edges/{edgeId}/assignments/{sessionId}/{assignmentEpoch}/release": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    edgeId: string;
                    sessionId: string;
                    assignmentEpoch: number;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Released */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid lease release */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid lease */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/callbacks/checkpoints": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: uuid */
                        sessionId: string;
                        runtimeId: string;
                        /** @enum {string} */
                        runtimeKind: "Cloud" | "VenueEdge";
                        assignmentEpoch: number;
                        presentationRevision: number;
                        version: number;
                        lastSequence: number;
                        idempotencyKey: string;
                        payload: unknown | boolean | number | string | unknown[] | {
                            [key: string]: unknown;
                        };
                    };
                };
            };
            responses: {
                /** @description Persistence result */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            applied: boolean;
                        };
                    };
                };
                /** @description Invalid callback */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime assignment is not active */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Checkpoint payload exceeds its byte limit */
                413: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/callbacks/completions": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** Format: uuid */
                        sessionId: string;
                        runtimeId: string;
                        /** @enum {string} */
                        runtimeKind: "Cloud" | "VenueEdge";
                        assignmentEpoch: number;
                        presentationRevision: number;
                        checkpointVersion: number;
                        lastSequence: number;
                        idempotencyKey: string;
                        /** Format: date-time */
                        startedAt: string;
                        /** Format: date-time */
                        endedAt: string;
                        participantCount: number;
                        participants: {
                            userId: string;
                            /** @enum {string} */
                            role: "presenter" | "viewer";
                        }[];
                        finalCheckpoint: unknown | boolean | number | string | unknown[] | {
                            [key: string]: unknown;
                        };
                    };
                };
            };
            responses: {
                /** @description Persistence result */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            applied: boolean;
                        };
                    };
                };
                /** @description Invalid callback */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime assignment is not active */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Checkpoint payload exceeds its byte limit */
                413: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{presentationId}/builds": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    presentationId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        /** @description RFC 8785 canonical PresentationDefinition JSON */
                        definitionJson: string;
                        /** @description RFC 8785 canonical RenderBundle JSON */
                        renderBundleJson: string;
                        /** @description RFC 8785 canonical AssetSetManifest JSON */
                        assetSetJson: string;
                        /** @description RFC 8785 canonical BuildManifest JSON */
                        buildManifestJson: string;
                    };
                };
            };
            responses: {
                /** @description Build stored */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            buildId: string;
                            assetIds: string[];
                        };
                    };
                };
                /** @description Invalid build */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Presentation not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Build conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid build semantics */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{presentationId}/builds/{buildId}/assets/{assetId}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    presentationId: string;
                    buildId: string;
                    assetId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/octet-stream": unknown;
                };
            };
            responses: {
                /** @description Asset stored */
                204: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content?: never;
                };
                /** @description Invalid asset */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Build not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Asset bytes mismatch */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{presentationId}/publications": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    presentationId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        buildId: string;
                        expectedPublicationFence: {
                            presentationId: string;
                            publicationEpoch: number;
                            publicationManifestHash: string;
                        } | null;
                    };
                };
            };
            responses: {
                /** @description Published */
                201: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** @enum {number} */
                            schemaVersion: 1;
                            presentationId: string;
                            publicationEpoch: number;
                            publicationManifestHash: string;
                            sourceDraftRevision: number;
                            buildId: string;
                            definitionHash: string;
                            renderBundleHash: string;
                            assetSetHash: string;
                            contractVersions: {
                                /** @enum {number} */
                                definition: 1;
                                /** @enum {number} */
                                renderBundle: 1;
                                /** @enum {number} */
                                assetSet: 1;
                                /** @enum {number} */
                                delivery: 3;
                                /** @enum {number} */
                                runtime: 3;
                                /** @enum {number} */
                                progression: 2;
                                /** @enum {number} */
                                projection: 2;
                            };
                        };
                    };
                };
                /** @description Invalid publication */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Build not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Active use or epoch conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid build assets */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{presentationId}/builds/{buildId}/thumbnail": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    presentationId: string;
                    buildId: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description First published baked texture */
                200: {
                    headers: {
                        "Cache-Control"?: "private, no-store";
                        "X-Content-Type-Options"?: "nosniff";
                        "Content-Length"?: string;
                        [name: string]: unknown;
                    };
                    content: {
                        "image/png": string;
                    };
                };
                /** @description Invalid build path */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Published build or texture not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Published build or texture integrity mismatch */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/presentations/{presentationId}/publication": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    presentationId: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Current publication */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** @enum {number} */
                            schemaVersion: 1;
                            presentationId: string;
                            publicationEpoch: number;
                            publicationManifestHash: string;
                            sourceDraftRevision: number;
                            buildId: string;
                            definitionHash: string;
                            renderBundleHash: string;
                            assetSetHash: string;
                            contractVersions: {
                                /** @enum {number} */
                                definition: 1;
                                /** @enum {number} */
                                renderBundle: 1;
                                /** @enum {number} */
                                assetSet: 1;
                                /** @enum {number} */
                                delivery: 3;
                                /** @enum {number} */
                                runtime: 3;
                                /** @enum {number} */
                                progression: 2;
                                /** @enum {number} */
                                projection: 2;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Forbidden */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Publication not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/sessions/{sessionId}/delivery": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get?: never;
        put?: never;
        post: {
            parameters: {
                query?: never;
                header?: never;
                path: {
                    sessionId: string;
                };
                cookie?: never;
            };
            requestBody: {
                content: {
                    "application/json": {
                        capabilityProfileId: string;
                    };
                };
            };
            responses: {
                /** @description Validated protobuf DeliveryManifest */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/x-protobuf": string;
                    };
                };
                /** @description Invalid capability selection */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Not a session participant */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Publication not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session or assignment conflict; runtime_unavailable is retryable while Runtime is unavailable */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Session ended */
                410: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                /** @enum {string} */
                                code: "session_ended";
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unsupported capability */
                422: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/publication-assets/{presentationId}/{buildId}/{assetId}": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query: {
                    expires: string;
                    signature: string;
                };
                header?: never;
                path: {
                    presentationId: string;
                    buildId: string;
                    assetId: string;
                };
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Verified immutable publication asset */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/octet-stream": unknown;
                    };
                };
                /** @description Invalid asset capability */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Invalid or expired asset capability */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Published asset not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Published asset integrity mismatch */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/assets": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query: {
                    sessionId: string;
                    runtimeId: string;
                    assignmentEpoch: number;
                    participantId: string;
                    assetId: string;
                };
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Authorized Venue Edge asset origin; never forward this URL to participants */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            assignment: {
                                sessionId: string;
                                runtimeId: string;
                                /** @enum {string} */
                                runtimeKind: "Cloud" | "VenueEdge";
                                assignmentEpoch: number;
                                presentationRevision: number;
                                /** Format: date-time */
                                leaseExpiresAt: string;
                            };
                            publication: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                                definitionHash: string;
                                renderBundleHash: string;
                            };
                            /** Format: uri */
                            url: string;
                            checksum: string;
                            size: number;
                            mediaType: string;
                        };
                    };
                };
                /** @description Invalid asset request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized service */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Asset not selected for participant */
                403: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime assignment or publication unavailable */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/bootstrap": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query: {
                    sessionId: string;
                    runtimeId: string;
                    assignmentEpoch: number;
                    /** @description Required for Venue Edge process startup; forbidden for managed Cloud Runtime */
                    executionBootId?: string;
                };
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Trusted Runtime v3 bootstrap */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            assignment: {
                                sessionId: string;
                                runtimeId: string;
                                /** @enum {string} */
                                runtimeKind: "Cloud" | "VenueEdge";
                                assignmentEpoch: number;
                                presentationRevision: number;
                                /** Format: date-time */
                                leaseExpiresAt: string;
                            };
                            publication: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                                definitionHash: string;
                                renderBundleHash: string;
                            };
                            /** @description PresentationDefinition; strict schema validated at storage boundary */
                            definition: {
                                [key: string]: unknown;
                            };
                            /** @description RenderBundle; strict schema validated at storage boundary; identity bound by publication.renderBundleHash */
                            renderBundle: {
                                [key: string]: unknown;
                            };
                            checkpoint: {
                                [key: string]: unknown;
                            } | null;
                            checkpointSource: {
                                runtimeId: string;
                                /** @enum {string} */
                                runtimeKind: "Cloud" | "VenueEdge";
                                assignmentEpoch: number;
                                checkpointSequence: number;
                            } | null;
                        };
                    };
                };
                /** @description Invalid bootstrap request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime assignment not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime fence conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Checkpoint payload exceeds its byte limit */
                413: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/lease": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query: {
                    sessionId: string;
                    runtimeId: string;
                    assignmentEpoch: number;
                };
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Current Runtime assignment and pinned publication fence */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            assignment: {
                                sessionId: string;
                                runtimeId: string;
                                /** @enum {string} */
                                runtimeKind: "Cloud" | "VenueEdge";
                                assignmentEpoch: number;
                                presentationRevision: number;
                                /** Format: date-time */
                                leaseExpiresAt: string;
                            };
                            publication: {
                                presentationId: string;
                                publicationEpoch: number;
                                publicationManifestHash: string;
                                definitionHash: string;
                                renderBundleHash: string;
                            };
                        };
                    };
                };
                /** @description Invalid lease request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Runtime fence conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Checkpoint payload exceeds its byte limit */
                413: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/internal/runtime/projection": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query: {
                    sessionId: string;
                    participantId: string;
                };
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Trusted participant projection */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            /** @enum {string} */
                            role: "presenter" | "viewer";
                            /** @description ProjectionProfileDescriptor ProtoJSON; validated by Realtime wire contract */
                            profile: {
                                [key: string]: unknown;
                            };
                        };
                    };
                };
                /** @description Invalid projection request */
                400: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Unauthorized */
                401: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Participant not found */
                404: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
                /** @description Publication or capability conflict */
                409: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            error: {
                                code: string;
                                message: string;
                            };
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
    "/.well-known/jwks.json": {
        parameters: {
            query?: never;
            header?: never;
            path?: never;
            cookie?: never;
        };
        get: {
            parameters: {
                query?: never;
                header?: never;
                path?: never;
                cookie?: never;
            };
            requestBody?: never;
            responses: {
                /** @description Realtime signing keys */
                200: {
                    headers: {
                        [name: string]: unknown;
                    };
                    content: {
                        "application/json": {
                            keys: {
                                /** @enum {string} */
                                kty: "OKP";
                                /** @enum {string} */
                                crv: "Ed25519";
                                x: string;
                                kid: string;
                                /** @enum {string} */
                                alg: "EdDSA";
                                /** @enum {string} */
                                use: "sig";
                                key_ops: "verify"[];
                            }[];
                        };
                    };
                };
            };
        };
        put?: never;
        post?: never;
        delete?: never;
        options?: never;
        head?: never;
        patch?: never;
        trace?: never;
    };
}
export type webhooks = Record<string, never>;
export interface components {
    schemas: never;
    responses: never;
    parameters: never;
    requestBodies: never;
    headers: never;
    pathItems: never;
}
export type $defs = Record<string, never>;
export type operations = Record<string, never>;
